/*
	Matthew Kehoe
*/

public class Warship extends GenericShip
{
	private int torpedos;
	private int phaserBanks;
	private double shield;
	private String captain;
	
	public Warship()
	{
		torpedos = 2;
		phaserBanks= 2;
		shield = 100.0;
		captain = "Snuggles";
	}
	
	public Warship(int torpedos, int phaserBanks, double shield, String captain)
	{
		this.torpedos = torpedos;
		this.phaserBanks = phaserBanks;
		this.shield = shield;
		this.captain = captain;
	}
	
	public void setTorpedos(int torpedos)
	{
		this.torpedos = torpedos;
	}
	
	public void setPhasers(int phaserBanks)
	{
		this.phaserBanks = phaserBanks;
	}
	
	public void setShieldStrength(double shield)
	{
		this.shield = shield;
	}
	
	public void setCaptain(String captain)
	{
		this.captain = captain;
	}
	
	public int getTorpedos()
	{
		return torpedos;
	}
	
	public int getPhasers()
	{
		return phaserBanks;
	}
	
	public double getShieldStrength()
	{
		return shield;
	}
	
	public String getCaptain()
	{
		return captain;
	}
	
	public int FireAway()
	{
		int damage;
		damage = (int) (Math.random() * 100 + 1);
		return damage;
	}
}
