/*
	Matthew Kehoe
*/

public class ScienceVessel extends GenericShip
{
	private int probes;
	private int scientist;
	private String chiefResearcher;
	
	public ScienceVessel()
	{
		probes = 10;
		scientist = 25;
		chiefResearcher = "Cochrane";
	}
	
	public ScienceVessel(int probes, int scientist, String chiefResearcher)
	{
		this.probes = probes;
		this.scientist = scientist;
		this.chiefResearcher = chiefResearcher;
	}
	
	public void setProbes(int probes)
	{
		this.probes = probes;
	}
	
	public void setScientist(int scientist)
	{
		this.scientist = scientist;
	}
	
	public void setChiefResearcher(String chiefResearcher)
	{
		this.chiefResearcher = chiefResearcher;
	}
	
	public int getProbes()
	{
		return probes;
	}
	
	public int getScientist()
	{
		return scientist;
	}
	
	public String getChiefResearcher()
	{
		return chiefResearcher;
	}
	
	public void launchProbe()
	{
		if (probes > 0)
		{
			System.out.println("We�re launching the probe, sir.");
			probes--;
		}
		else
		{
			System.out.println("Sorry sir there are no probes left.");
		}
	}
}
