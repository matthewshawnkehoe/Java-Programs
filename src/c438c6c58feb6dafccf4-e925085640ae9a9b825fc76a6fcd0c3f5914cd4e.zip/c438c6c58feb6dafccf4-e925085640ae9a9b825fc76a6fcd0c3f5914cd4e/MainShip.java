import java.text.DecimalFormat;

/*
	Matthew Kehoe
*/

public class MainShip 
{
	public static void main(String[] args)
	{
		GenericShip fluffy = new GenericShip();
		Warship guerilla = new Warship();
		ScienceVessel magneto = new ScienceVessel();
		Transport scaredKitten = new Transport();
		
		DecimalFormat f = new DecimalFormat("##0,000.00");
		
		System.out.println("The generic ship has the following...");
		System.out.println();
		System.out.println("Default of " + fluffy.getCrew() + " crew members.");
		System.out.println("Default cost of $" + f.format(fluffy.getCost()) + ".");
		System.out.println("Default name of " 
				+ fluffy.getShipName() + ".");
		System.out.println();
		System.out.println("Now we can test a transport ship...");
		System.out.println();
		System.out.println("The default name for this ship is " + scaredKitten.getShipName());
		fluffy.setName("Kittens Of Doom.");
		System.out.println("The new name of this ship is " + fluffy.getShipName());
		fluffy.setCost(10000000);
		System.out.println("Because the name is spiffy, we have increased the " 
				+ "price of the ship to $" + f.format(fluffy.getCost()) + ".");
		scaredKitten.Help();
		System.out.println("Who likes transports ships anyway?");
		System.out.println();
		System.out.println("Lets go ahead and switch over to a warship...");
		System.out.println();
		System.out.println("It appears that the default cost of this ship is $" 
				+ f.format(guerilla.getCost()));
		guerilla.setCost(5000000);
		System.out.println("That doesn't sound right, lets increase the cost to $"
				+ f.format(guerilla.getCost()) );
		guerilla.setTorpedos(10);
		guerilla.setPhasers(100);
		System.out.println("The warship has " + guerilla.getTorpedos() + " torpedos " 
				+ "and " + guerilla.getPhasers() + " phasers.\nYou probably shouldn't "
				+ "try to attack with your transport ship.");
		System.out.println("If you do, the warship may do " + guerilla.FireAway() + 
				" damage to your ship. So, don't attack the warship with "
				+ "your transport ship.");
		System.out.println();
		System.out.println("Enough fighting, lets look at stars with the science "
				+ "vessel ship...");
		System.out.println();
		magneto.setProbes(5);
		System.out.println("This new ship has " + magneto.getScientist() + " scientist. "
				+ "We have increased the number of probes to " + magneto.getProbes() +
				".");
		magneto.setName("MAGENTO");
		System.out.println("The name is this ship is " + magneto.getShipName() + ".");
		System.out.println("We are starting at " + magneto.getProbes() + " probes."
				+ " Lets go ahead and launch some them into space!");
		System.out.println("Starting with some turbulence...");
		for (int i = magneto.getProbes(); i >= 0; i--)
		{
			magneto.launchProbe();
			if (i != 0)
			System.out.println("We now have " + magneto.getProbes() + " probes!");
		}
	}
}
