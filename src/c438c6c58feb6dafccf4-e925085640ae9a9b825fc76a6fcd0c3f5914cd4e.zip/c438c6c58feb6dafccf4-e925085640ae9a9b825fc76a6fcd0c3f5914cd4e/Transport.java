/*
	Matthew Kehoe

*/

public class Transport extends GenericShip
{
	private int materials;
	
	public Transport()
	{
		materials = 100;
	}
	
	public Transport(int materials)
	{
		this.materials = materials;
	}
	
	public void setTransport(int materials)
	{
		this.materials = materials;
	}
	
	public int getTransport()
	{
		return materials;
	}
	
	public void Help()
	{
		System.out.println("Help! We're under attack!");
	}
}
