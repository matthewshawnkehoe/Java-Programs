/*
 	Matthew Kehoe
 */

public class GenericShip 
{
	private int crew;
	private int cost;
	private String shipName;
	
	public GenericShip()
	{
		crew = 10;
		cost = 5000;
		shipName = "S.S. Default";
	}
	
	public GenericShip(int crew, int cost, String shipName)
	{
		this.crew = crew;
		this.cost = cost;
		this.shipName = shipName;
	}
	
	public void setCrew(int crew)
	{
		this.crew = crew;
	}
	
	public void setCost(int cost)
	{
		this.cost = cost;
	}
	
	public void setName(String shipName)
	{
		this.shipName = shipName;
	}
	
	public int getCrew()
	{
		return crew;
	}
	
	public int getCost()
	{
		return cost;
	}
	
	public String getShipName()
	{
		return shipName;
	}		
}
